# JasonPowerDb
i have done my internship in login2xplore using JSONDb database using talend api
